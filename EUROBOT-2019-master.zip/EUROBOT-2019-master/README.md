# EUROBOT-2019
Eurobot is an international amateur robotics contest open to teams of young people   in this contest you have to build an autonomous robot that can do certain tasks and collect point for each task
the code wasn't shared because it need to be organized

